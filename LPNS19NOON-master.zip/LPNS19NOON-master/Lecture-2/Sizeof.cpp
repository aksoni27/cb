// Sizeof
#include <iostream>
using namespace std;

int main(){
	int a=10;
	float b=10.1;
	char ch = 'A';
	bool c = true;

	cout<<sizeof(10)<<endl;	
	cout<<sizeof('A')<<endl;	
	cout<<sizeof(b)<<endl;	
	cout<<sizeof(ch)<<endl;	
	cout<<sizeof(c)<<endl;	


	return 0;
}