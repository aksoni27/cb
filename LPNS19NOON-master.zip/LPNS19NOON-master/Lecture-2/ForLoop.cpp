// ForLoop
#include <iostream>
using namespace std;

int main(){
	// int i = 1;
	// while(i<=10){
	// 	cout<<i<<" ";
	// 	i++;
	// }
	// cout<<endl;
	// for(init ; condition check ; updation){

	// }
	for(int i=1 ; i<=10 ; i++){
		cout<<i<<" ";
	}
	cout<<endl;







	return 0;
}