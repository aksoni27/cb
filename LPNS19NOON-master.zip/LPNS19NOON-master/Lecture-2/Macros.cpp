// Constants
#include <iostream>
using namespace std;
#define PI 3.14+1
#define SEMICOLON ;
#define PRINT cout

int main(){
	float pi = 3.14;
	pi = pi + 1;

	PRINT<<pi*10<<endl SEMICOLON
	PRINT<<PI*10<<endl SEMICOLON

	return 0;
}