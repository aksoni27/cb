// TypeCasting
#include <iostream>
using namespace std;

int main(){
	char ch='6';
	cout<<ch<<endl;
	int b = ch;

	cout<<b<<endl;
	cout<<ch+1<<endl;

	char a = ch + 1;
	cout<<a<<endl;
	cout<<a+1<<endl;


	return 0;
}