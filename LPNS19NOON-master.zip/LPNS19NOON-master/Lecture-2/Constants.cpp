// Constants
#include <iostream>
using namespace std;

int main(){
	const int area=3400;
	

	cout<<area+1<<endl;
	float pi = 3.14;
	pi = pi + 1;

	return 0;
}