// UpperAndLower
#include <iostream>
using namespace std;

int main(){
	char ch;
	cin>>ch;

	if(ch>='a'&&ch<='z'){
		cout<<"Lower"<<endl;
	}
	else{
		cout<<"Upper"<<endl;
	}


	return 0;
}