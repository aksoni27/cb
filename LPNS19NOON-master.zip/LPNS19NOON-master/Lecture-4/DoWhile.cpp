// DoWhile
#include <iostream>
using namespace std;

int main(){
	int a = 0;

	do{
		cout<<a<<" ";
		a++;
	}
	while(a<10);


	return 0;
}